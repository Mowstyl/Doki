#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>
#include "qstate.h"
#include "qgate.h"
#include "qops.h"


static PyObject *DokiError;

unsigned char
get_rounding_mode (mpc_rnd_t *rnd,
                   unsigned int real_rnd, unsigned int imag_rnd);
void
doki_registry_destroy (PyObject *capsule);

static PyObject *
doki_registry_new (PyObject *self, PyObject *args);

static PyObject *
doki_registry_get (PyObject *self, PyObject *args);

static PyMethodDef DokiMethods[] = {
    {"new", doki_registry_new, METH_VARARGS, "Create new registry"},
    {"get", doki_registry_get, METH_VARARGS, "Get value from registry"},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef dokimodule = {
    PyModuleDef_HEAD_INIT,
    "doki",   /* name of module */
    NULL, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    DokiMethods
};

PyMODINIT_FUNC
PyInit_doki(void)
{
    PyObject *m;

    m = PyModule_Create(&dokimodule);
    if (m == NULL)
        return NULL;

    DokiError = PyErr_NewException("qsimov.doki.error", NULL, NULL);
    Py_XINCREF(DokiError);
    if (PyModule_AddObject(m, "error", DokiError) < 0) {
        Py_XDECREF(DokiError);
        Py_CLEAR(DokiError);
        Py_DECREF(m);
        return NULL;
    }

    return m;
}

int
main(int argc, char *argv[])
{
    wchar_t *program = Py_DecodeLocale(argv[0], NULL);
    if (program == NULL) {
        fprintf(stderr, "Fatal error: cannot decode argv[0]\n");
        exit(1);
    }

    /* Add a built-in module, before Py_Initialize */
    if (PyImport_AppendInittab("doki", PyInit_doki) == -1) {
        fprintf(stderr, "Error: could not extend in-built modules table\n");
        exit(1);
    }

    /* Pass argv[0] to the Python interpreter */
    Py_SetProgramName(program);

    /* Initialize the Python interpreter.  Required.
       If this step fails, it will be a fatal error. */
    Py_Initialize();

    /* Optionally import the module; alternatively,
       import can be deferred until the embedded script
       imports it. */
    PyObject *pmodule = PyImport_ImportModule("doki");
    if (!pmodule) {
        PyErr_Print();
        fprintf(stderr, "Error: could not import module 'spam'\n");
    }
    PyMem_RawFree(program);
    return 0;
}

unsigned char
get_rounding_mode (mpc_rnd_t *rnd,
                   unsigned int real_rnd, unsigned int imag_rnd)
{
  unsigned char result = 0;
  switch (real_rnd * 10 + imag_rnd)
    {
      case 0:
        *rnd = MPC_RNDNN;
        break;
      case 1:
        *rnd = MPC_RNDNZ;
        break;
      case 2:
        *rnd = MPC_RNDNU;
        break;
      case 3:
        *rnd = MPC_RNDND;
        break;
      case 10:
        *rnd = MPC_RNDZN;
        break;
      case 11:
        *rnd = MPC_RNDZZ;
        break;
      case 12:
        *rnd = MPC_RNDZU;
        break;
      case 13:
        *rnd = MPC_RNDZD;
        break;
      case 20:
        *rnd = MPC_RNDUN;
        break;
      case 21:
        *rnd = MPC_RNDUZ;
        break;
      case 22:
        *rnd = MPC_RNDUU;
        break;
      case 23:
        *rnd = MPC_RNDUD;
        break;
      case 30:
        *rnd = MPC_RNDDN;
        break;
      case 31:
        *rnd = MPC_RNDDZ;
        break;
      case 32:
        *rnd = MPC_RNDDU;
        break;
      case 33:
        *rnd = MPC_RNDDD;
        break;
      default:
        result = 1;
    }
  return result;
}

void
doki_registry_destroy (PyObject *capsule)
{
    struct state_vector *state;
    void *raw_state;
    printf("[DEBUG] Deleting\n");
    raw_state = PyCapsule_GetPointer(capsule, "qsimov.doki.state_vector");
    printf("[DEBUG] Uncapsulated\n");
    state = (struct state_vector*) raw_state;
    printf("[DEBUG] Clearing\n");
    state_clear(*state);
    printf("[DEBUG] Freeing\n");
    free(state);
    printf("[DEBUG] Done\n");
}

static PyObject *
doki_registry_new (PyObject *self, PyObject *args)
{
    unsigned int num_qubits, prec_bits, real_rnd, imag_rnd;
    mpc_rnd_t rnd;
    unsigned char result;
    struct state_vector *state;

    if (!PyArg_ParseTuple(args, "IIII", &num_qubits, &prec_bits, &real_rnd,
        &imag_rnd))
    {
        PyErr_SetString(DokiError, "Syntax: new(num_qubits, prec_bits, "
                                   "real_round, imag_round)");
        return NULL;
    }
    if (num_qubits == 0) {
        PyErr_SetString(DokiError, "num_qubits can't be zero");
        return NULL;
    }
    if (prec_bits == 0) {
        PyErr_SetString(DokiError, "prec_bits can't be zero");
        return NULL;
    }
    if (real_rnd > 3) {
        PyErr_SetString(DokiError, "real_rnd must be in [0, 3]");
        return NULL;
    }
    if (imag_rnd > 3) {
        PyErr_SetString(DokiError, "imag_rnd must be in [0, 3]");
        return NULL;
    }
    if (get_rounding_mode (&rnd, real_rnd, imag_rnd) != 0) {
        PyErr_SetString(DokiError, "Error getting rounding mode");
        return NULL;
    }

    state = (struct state_vector*) malloc(sizeof *state);
    if (state == NULL) {
        PyErr_SetString(DokiError, "Failed to allocate state vector");
        return NULL;
    }
    result = state_init(*state, num_qubits, prec_bits, rnd, 1);
    if (result == 1) {
        PyErr_SetString(DokiError, "Failed to initialize state chunk");
        return NULL;
    }
    else if (result == 2) {
        PyErr_SetString(DokiError, "Failed to allocate state chunk");
        return NULL;
    }
    else if (result == 3) {
        PyErr_SetString(DokiError, "Failed to set first value to 1");
        return NULL;
    }
    else if (result == 4) {
        PyErr_SetString(DokiError, "Failed to allocate state structure");
        return NULL;
    }
    else if (result != 0) {
        printf("[DEBUG]: Unknown code %u\n", result);
        PyErr_SetString(DokiError, "Unknown error when creating state");
        return NULL;
    }
    return PyCapsule_New((void*) state, "qsimov.doki.state_vector",
                         &doki_registry_destroy);
}

static PyObject *
doki_registry_get (PyObject *self, PyObject *args)
{
    PyObject *capsule, *result;
    void *raw_state;
    struct state_vector *state;
    mpz_t id;
    mpc_t val;
    char *raw_id, *raw_result;
    unsigned char exit_code;
    unsigned int significant_digits;

    printf("[DEBUG] Getting arguments\n");
    if (!PyArg_ParseTuple(args, "OsI", capsule, raw_id, &significant_digits)) {
        printf("[DEBUG] Fail\n");
        PyErr_SetString(DokiError, "Syntax: get(registry, id, sig_digits)");
        return NULL;
    }

    printf("[DEBUG] Getting pointer from capsule\n");
    raw_state = PyCapsule_GetPointer(capsule, "qsimov.doki.state_vector");
    if (raw_state == NULL) {
        PyErr_SetString(DokiError, "NULL pointer to registry");
        return NULL;
    }
    printf("[DEBUG] Casting pointer\n");
    state = (struct state_vector*) raw_state;
    printf("[DEBUG] Getting string from value\n");
    mpz_init_set_str(id, raw_id, 10);
    exit_code = state_get(*state, id, &val);
    if (exit_code == 1) {
        PyErr_SetString(DokiError, "Not here");
        return NULL;
    }
    else if (exit_code == 2) {
        PyErr_SetString(DokiError, "Out of bounds");
        return NULL;
    }
    raw_result = mpc_get_str(10, significant_digits, val,
                             state->rounding_mode);
    result = PyUnicode_FromString(raw_result);
    mpc_free_str(raw_result);

    return result;
}
