#include <stdlib.h>
#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>
#include "qstate.h"
#include "qgate.h"
#include "qops.h"

unsigned char
apply_gate(struct state_vector state, struct qgate gate,
           unsigned int *targets, unsigned int num_targets,
           unsigned int *controls, unsigned int num_controls,
           unsigned int *anticontrols, unsigned int num_anticontrols)
{
    struct state_vector new_state;
    mpz_t i, reg_index;
    mpc_t aux, sum, get;
    unsigned char exit_code, next;
    unsigned int *colbits, *rowbits;
    unsigned int j, k, row;

    exit_code = state_init(new_state, state.num_qubits,
                           state.precision_bits, state.rounding_mode, 0);
    // 0 -> OK
    // 1 -> Error initializing chunk
    // 2 -> Error allocating chunk
    // 3 -> Error setting values (should never happens since init = 0)
    if (exit_code != 0) {
        return exit_code;
    }
    colbits = (unsigned int*) malloc((sizeof *colbits) * gate.num_qubits);
    rowbits = (unsigned int*) malloc((sizeof *rowbits) * gate.num_qubits);
    if (colbits == NULL || rowbits == NULL) {
        state_clear(new_state);
        return 4;  // Failed to allocate colbits and rowbits
    }
    mpz_init(i);
    mpz_init(reg_index);
    mpc_init2(sum, state.precision_bits);
    mpc_init2(aux, state.precision_bits);


    for (mpz_set_ui(i, 0); mpz_cmp(i, state.size) < 0; mpz_add_ui(i, i, 1)) {
        if (exit_code != 0) {
            break;
        }
        next = 0;

        for (j = 0; j < num_controls; j++) {
            if (mpz_tstbit(i, controls[j]) != 1) {
                next = 1;
                break;
            }
        }
        if (!next) {
            for (j = 0; j < num_anticontrols; j++) {
                if (mpz_tstbit(i, anticontrols[j]) != 0) {
                    next = 1;
                    break;
                }
            }
        }
        if (next) {
            /*
             * 1 -> Not in this computation node (can be ignored)
             * 2 -> Out of bounds
             */
            exit_code = state_get(state, i, &get);
            if (exit_code <= 1) {
                exit_code = state_set(new_state, i, get);
                if (exit_code <= 1) {
                    exit_code = 0;
                }
            }
            continue;
        }
        mpz_set(reg_index, i);
        mpc_set_ui(sum, 0, state.rounding_mode);
        for (j = 0; j < gate.size; j++) {
            get_bits_ui(colbits, gate.num_qubits, j);
            for (k = 0; k < num_targets; k++) {
                rowbits[k] = mpz_tstbit(i, targets[k]);
            }
            for (k = 0; k < gate.num_qubits; k++) {
                if (colbits[k]) {
                    mpz_setbit(reg_index, targets[k]);
                }
                else {
                    mpz_clrbit(reg_index, targets[k]);
                }
            }
            row = get_ui_bits(rowbits, num_targets);
            state_get(state, reg_index, &get);
            mpc_mul(aux, get, gate.matrix[row][j], state.rounding_mode);
            mpc_add(sum, sum, aux, state.rounding_mode);
        }
        if (state_set (new_state, i, sum) > 1) {
            exit_code = 1;
        }
    }
    mpc_clear(sum);
    mpc_clear(aux);
    mpz_clear(reg_index);
    mpz_clear(i);
    free(colbits);
    free(rowbits);

    if (exit_code == 0) {
        state_clear(state);
        mpz_init_set(state.first_id, new_state.first_id);
        mpz_init_set(state.last_id, new_state.last_id);
        mpz_init_set(state.size, new_state.size);
        state.vector = new_state.vector;
        new_state.vector = NULL;
    }
    else {
        exit_code = 5;  // 5 -> Out of bounds
    }
    state_clear(new_state);

    return exit_code;
}

void
get_bits_ui (unsigned int *bits, unsigned int num_bits, unsigned int n)
{
    unsigned int i, aux;

    aux = n;
    for (i = 0; i < num_bits; i++) {
        bits[i] = aux & 1;
        aux = aux >> 1;
    }
}

unsigned int
get_ui_bits (unsigned int *bits, unsigned int num_bits)
{
    unsigned int j, result;
    result = 0;
    for (j = num_bits - 1; j >= 0; j--) {
        result += bits[j];
        if (j > 0) {
            result = result << 1;
        }
    }
    return result;
}
