import platform
import os
from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext

ON_WINDOWS = platform.system() == "Windows"
_comp_args = ["DSHARED=1"]
sources = ["qstate.c", "qops.c", "doki.c"]

class DokiBuild(build_ext):
    description = "Build Doki with custom build options"
    user_options = build_ext.user_options + [
        ('fast', None,
         "Depend on MPFR and MPC internal implementations details"
         "(even more than the standard build)"),
        ('gcov', None, "Enable GCC code coverage collection"),
        ('vector', None, "Include the vector_XXX() functions;"
         "they are unstable and under active development"),
        ('static', None, "Enable static linking compile time options."),
        ('static-dir=', None, "Enable static linking and specify location."),
        ('gdb', None, "Build with debug symbols."),
    ]

    def initialize_options(self):
        build_ext.initialize_options(self)
        self.fast = False
        self.gcov = False
        self.vector = False
        self.static = False
        self.static_dir = False
        self.gdb = False

    def finalize_options(self):
        build_ext.finalize_options(self)
        if self.fast:
            _comp_args.append('DFAST=1')
        if self.gcov:
            if ON_WINDOWS:
                raise ValueError("Cannot enable GCC code coverage on Windows")
            _comp_args.append('DGCOV=1')
            _comp_args.append('O0')
            _comp_args.append('-coverage')
            self.libraries.append('gcov')
        if self.vector:
            _comp_args.append('DVECTOR=1')
        if self.static:
            _comp_args.remove('DSHARED=1')
            _comp_args.append('DSTATIC=1')
        if self.gdb:
            _comp_args.append('ggdb')
        if self.static_dir:
            _comp_args.remove('DSHARED=1')
            _comp_args.append('DSTATIC=1')
            self.include_dirs.append(self.static_dir + '/include')
            self.library_dirs.append(self.static_dir + '/lib')

    def build_extensions(self):
        compiler = self.compiler.compiler_type
        if compiler == 'mingw32':
            _comp_args.append('DMSYS2=1')
        elif ON_WINDOWS and not self.static:
            # MSVC shared build
            _comp_args.append('DMSC_USE_DLL')
        _prefix = '-' if compiler != 'msvc' else '/'
        for i in range(len(_comp_args)):
            _comp_args[i] = ''.join([_prefix, _comp_args[i]])
        build_ext.build_extensions(self)


extensions = [
    Extension('doki',
              sources=sources,
              include_dirs=[r"C:\libs\x64\include"],
              library_dirs=[r"C:\libs\x64\wlib"],
              libraries=[r"libgmp-10",
                         r"libmpfr-6",
                         r"libmpc-3"],
              extra_compile_args=_comp_args,
              )
]

cmdclass = {'build_ext': DokiBuild}


def main():
    setup(
        name="doki",
        version="1.0.0",
        author="Hernán Indíbil de la Cruz Calvo",
        author_email="HernanIndibil.LaCruz@alu.uclm.es",
        cmdclass=cmdclass,
        license="MIT",
        url="https://github.com/Mowstyl/QSimov",
        description="Python interface for Doki (QSimov core)",
        long_description="TODO",
        zip_safe=False,
        include_package_data=True,
        package_data={'doki': [
            '*.pxd',
        ]},
        packages=find_packages(),
        classifiers=[
            'Programming Language :: C',
            'Programming Language :: Python :: 2',
            'Programming Language :: Python :: 2.7',
            'Programming Language :: Python :: 3',
            'Programming Language :: Python :: 3.5',
            'Programming Language :: Python :: 3.6',
            'Programming Language :: Python :: 3.7',
            'Programming Language :: Python :: 3.8',
            'Programming Language :: Python :: Implementation :: CPython',
            'Topic :: Scientific/Engineering :: Mathematics',
            'Topic :: Software Development :: Libraries :: Python Modules',
        ],
        keywords="quantum",
        ext_modules=extensions,
    )


if __name__ == "__main__":
    main()
