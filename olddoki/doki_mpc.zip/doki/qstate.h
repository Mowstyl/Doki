#ifndef __QSTATE_H
#define __QSTATE_H

#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>

struct array_list
{
  /* size of this chunk */
  unsigned int       node_size;
  /* array of elements in this chunk */
  mpc_ptr            node_elements;
  /* pointer to next chunk */
  struct array_list *next;
};

struct state_vector
{
  /* id of the first element stored in this computation node */
  mpz_t              first_id;
  /* id of the last element stored in this computation node */
  mpz_t              last_id;
  /* total (not partial) size of the vector */
  mpz_t              size;
  /* number of qubits in this quantum system */
  unsigned int       num_qubits;
  /* precision measured in bits */
  mpfr_prec_t        precision_bits;
  /* rounding mode */
  mpc_rnd_t          rounding_mode;
  /* partial vector */
  struct array_list *vector;
};

unsigned char
list_new(struct array_list *this, mpz_t size, mpfr_prec_t prec_bits,
         mpc_rnd_t rnd, int init);

void
list_clear(struct array_list *this);

unsigned char
list_chunk(struct array_list *this, mpfr_prec_t prec_bits,
           mpc_rnd_t rnd, int init);

unsigned char
state_init(struct state_vector state, unsigned int num_qubits,
           mpfr_prec_t prec_bits, mpc_rnd_t rnd, int init);

void
state_clear(struct state_vector state);

unsigned char
state_set(struct state_vector state, mpz_t index, mpc_t value);

unsigned char
state_set_si(struct state_vector state, mpz_t index, int value);

unsigned char
state_set_d(struct state_vector state, mpz_t index, double value);

unsigned char
state_get(struct state_vector state, mpz_t index, mpc_t *target);

#endif
