#ifndef __QGATE_H
#define __QGATE_H

#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>

struct qgate
{
  /* number of qubits affected by this gate */
  unsigned int       num_qubits;
  /* number of rows (or columns) in this gate */
  unsigned int       size;
  /* matrix that represents the gate */
  mpc_t            **matrix;
};

#endif
