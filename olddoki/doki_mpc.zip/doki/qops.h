#ifndef __QOPS_H
#define __QOPS_H

#include "qstate.h"
#include "qgate.h"

void
get_bits_ui(unsigned int *bits, unsigned int num_bits, unsigned int n);

unsigned int
get_ui_bits(unsigned int *bits, unsigned int num_bits);

unsigned char
apply_gate(struct state_vector state, struct qgate gate,
           unsigned int *targets, unsigned int num_targets,
           unsigned int *controls, unsigned int num_controls,
           unsigned int *anticontrols, unsigned int num_anticontrols);

#endif
