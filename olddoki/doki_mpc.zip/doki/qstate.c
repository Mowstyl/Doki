#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>
#include "qstate.h"


unsigned char
list_chunk(struct array_list *this, mpfr_prec_t prec_bits, mpc_rnd_t rnd,
           int init)
{
    /*
    Returns 0 if everything went well.
    Returns 1 if malloc for node_elements failed.
    */
    unsigned int i;

    this->node_elements = (mpc_ptr) malloc(this->node_size * (sizeof *(this->node_elements)));
    if (this->node_elements == NULL) {
        return 1;
    }
    for (i = 0; i < this->node_size; i++) {
        mpc_init2(this->node_elements + i, prec_bits);
    }
    if (!init) {
        return 0;
    }
    for (i = 0; i < this->node_size; i++) {
        printf("[DEBUG] Setting elem %u to 0\n", i);
        mpc_set_ui(this->node_elements + i, 0, rnd);
    }
    printf("[DEBUG] Done init\n", i);
    return 0;
}

unsigned char
list_new(struct array_list *this, mpz_t size, mpfr_prec_t prec_bits,
          mpc_rnd_t rnd, int init)
{
    unsigned int chunk_size, remainder, num_chunks, i;
    mpz_t aux;
    struct array_list *last;

    if (mpz_cmp_ui(size, INT_MAX) <= 0) {
        chunk_size = 0;
        num_chunks = 1;
        remainder = mpz_get_ui(size);
        // printf("[DEBUG]: List fits in one chunk\n");
    }
    else {
        mpz_init(aux);
        remainder = mpz_cdiv_q_ui(aux, size, INT_MAX);
        chunk_size = INT_MAX;
        num_chunks = mpz_get_ui(aux);
        mpz_clear(aux);
        if (remainder > 0) {
            num_chunks++;
        }
        // printf("[DEBUG]: List splitted in %u chunks\n", num_chunks);
    }
    last = this;
    for (i = 0; i < num_chunks - 1; i++) {
        last->node_size = chunk_size;
        /* Check if chunk gen returns error */
        if (list_chunk(last, prec_bits, rnd, init) != 0) {
            last->next = NULL;
            list_clear(this);
            return 1;  // Error 1 means failed to initialize chunk
        }
        last->next = (struct array_list*) malloc(sizeof *(last->next));
        if (last->next == NULL) {
            list_clear(this);
            return 2;  // Error 2 means failed to allocate chunk
        }
        last = last->next;
    }
    // printf("[DEBUG]: Initialized all chunks but the last one (if remainder > 0)\n");
    if (remainder > 0) {
        last->next = NULL;
        last->node_size = remainder;
        if (list_chunk(last, prec_bits, rnd, init) != 0) {
            /* Error 1 means failed to initialize chunk */
            return 1;
        }
        // printf("[DEBUG]: Initialized remainder chunk\n");
    }

    return 0;
}

void
list_clear(struct array_list *this)
{
    printf("[DEBUG] Called!\n");
    struct array_list *curr, *next;
    unsigned int i;

    printf("[DEBUG] Assigning next to first chunk\n");
    next = this;
    // We free memory of the complex array for each chunk
    printf("[DEBUG] Cleaning loop started!\n");
    while (next != NULL) {
        printf("[DEBUG] Switching to next chunk\n");
        curr = next;
        printf("[DEBUG] Chunk MPC Cleanup\n");
        printf("[DEBUG] Chunk of size %u\n", curr->node_size);
        /*
        for (i = 0; i < curr->node_size; i++) {
            printf("[DEBUG] Clearing %u\n", i);
            mpc_clear(this->node_elements + i);
        }
        */
        printf("[DEBUG] Freeing structures\n");
        free(curr->node_elements);
        next = curr->next;
        // printf("[DEBUG] Freeing current chunk\n");
        // free(curr);
    }
    printf("[DEBUG] Cleaning loop ended!\n");
}

unsigned char
state_init(struct state_vector state, unsigned int num_qubits,
           mpfr_prec_t prec_bits, mpc_rnd_t rnd, int init)
{
    unsigned char vector_result;
    mpz_t i;

    mpz_init_set_ui(state.first_id, 0);
    mpz_init_set_ui(state.size, 2);
    mpz_pow_ui(state.size, state.size, num_qubits);
    mpz_init(state.last_id);
    mpz_sub_ui(state.last_id, state.size, 1);
    state.precision_bits = prec_bits;
    state.rounding_mode = rnd;
    state.num_qubits = num_qubits;
    // printf("[DEBUG]: Allocating state vector...\n");
    state.vector = (struct array_list*) malloc(sizeof *(state.vector));
    if (state.vector != NULL) {
        // printf("[DEBUG]: Initializing state vector to 0...\n");
        vector_result = list_new(state.vector, state.size, state.precision_bits,
                                 state.rounding_mode, init);
    }
    else {
        // printf("[DEBUG]: Error allocating state vector...\n");
        vector_result = 4;
    }
    if (vector_result == 0 && init) {
        // printf("[DEBUG]: Setting first element to 1...\n");
        mpz_init_set_ui(i, 0);
        vector_result = state_set_si(state, i, 1);
        mpz_clear (i);
        if (vector_result != 0) {
            vector_result += 2;
        }
        // printf("[DEBUG]: Code %u setting one\n", vector_result);
    }
    if (vector_result > 0) {
        // printf("[DEBUG]: Error initializing state vector, clearing state...\n");
        state_clear(state);
    }

    return vector_result;
}


void
state_clear(struct state_vector state)
{
    printf("[DEBUG] Started clearing state...\n");
    if (state.vector != NULL) {
        printf("[DEBUG] Clearing vector %p...\n", state.vector);
        list_clear(state.vector);
        printf("[DEBUG] Cleared vector\n");
    }
    printf("[DEBUG] Clearing first_id...\n");
    mpz_clear(state.first_id);
    printf("[DEBUG] Clearing last_id...\n");
    mpz_clear(state.last_id);
    printf("[DEBUG] Clearing size...\n");
    mpz_clear(state.size);
    printf("[DEBUG] Clean state!\n");
}

unsigned char
state_set_si(struct state_vector state, mpz_t index, int raw_value)
{
    unsigned char res;
    mpc_t value;

    mpc_init2(value, state.precision_bits);
    mpc_set_ui(value, raw_value, state.rounding_mode);  // MPC_RNDNN
    res = state_set(state, index, value);
    mpc_clear(value);

    return res;
}

unsigned char
state_set_d(struct state_vector state, mpz_t index, double raw_value)
{
    unsigned char res;
    mpc_t value;

    mpc_init2(value, state.precision_bits);
    mpc_set_d(value, raw_value, state.rounding_mode);  // MPC_RNDNN
    res = state_set(state, index, value);
    mpc_clear(value);

    return res;
}

unsigned char
state_set(struct state_vector state, mpz_t index, mpc_t value)
{
    unsigned int position, i;
    mpz_t chunk_id, partial_id;
    struct array_list *chunk;

    if (mpz_cmp(index, state.size) >= 0)
    return 2;  // 1 means index out of bounds

    if (mpz_cmp(index, state.first_id) < 0 ||
        mpz_cmp(index, state.last_id) > 0)
    {
        /* Not in this computation node */
        return 1;
    }

    mpz_init(partial_id);
    mpz_sub(partial_id, index, state.first_id);
    mpz_init(chunk_id);
    position = mpz_cdiv_q_ui(chunk_id, partial_id, state.vector->node_size);
    mpz_clear(partial_id);
    chunk = state.vector;
    for (i = 0; mpz_cmp_ui(chunk_id, i) > 0; i++) {
        chunk = chunk->next;
    }
    mpz_clear(chunk_id);
    mpc_set(chunk->node_elements + position, value, state.rounding_mode);

    return 0;
}

unsigned char
state_get(struct state_vector state, mpz_t index, mpc_t *target)
{
    unsigned int position, i;
    mpz_t chunk_id, partial_id;
    struct array_list *chunk;

    if (mpz_cmp(index, state.size) >= 0) {
        printf("[DEBUG] Out of bounds\n");
        return 2;  // 1 means index out of bounds
    }

    if (mpz_cmp(index, state.first_id) < 0 ||
        mpz_cmp(index, state.last_id) > 0)
    {
        printf("[DEBUG] Not in this node\n");
        /* Not in this computation node */
        return 1;
    }
    printf("[DEBUG] Started getting value\n");

    mpz_init(partial_id);
    mpz_sub(partial_id, index, state.first_id);
    mpz_init(chunk_id);
    position = mpz_cdiv_q_ui(chunk_id, partial_id, state.vector->node_size);
    mpz_clear(partial_id);
    printf("[DEBUG] Calculated position and chunk\n");
    chunk = state.vector;
    for (i = 0; mpz_cmp_ui(chunk_id, i) > 0; i++) {
        chunk = chunk->next;
    }
    printf("[DEBUG] Found chunk\n");
    mpz_clear(chunk_id);
    mpc_init2(*target, state.precision_bits);
    mpc_set(*target, chunk->node_elements + position, state.rounding_mode);
    printf("[DEBUG] Copied value to target\n");

    return 0;
}
