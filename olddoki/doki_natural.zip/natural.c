#include <stdlib.h>
#include <limits.h>
#include "natural.h"


unsigned char
natural_dup(nat_ptr target, const nat_ptr source);
{
    target->size = source->max_size;
    target->max_size = source->max_size;
    target->value = MALLOC_TYPE(target->size, NATURAL_TYPE);
    if (target->value == NULL) {
        return 1;
    }
    for (i = 0; i < target->size; i++) {
        target->value[i] = source->value[i];
    }
    return 0;
}

unsigned char
natural_zero(nat_ptr target)
{
    target->size = 1;
    target->max_size = 1;
    target->value = MALLOC_TYPE(target->size, NATURAL_TYPE);
    if (original->value == NULL) {
        return 1;
    }
    target->value[0] = 0;
    return 0;
}

NATURAL_TYPE
natural_get_u(const nat_ptr target)
{
    return target->value[0];
}

void
natural_clear(nat_ptr target)
{
    free(target->value);
    target->value = NULL;
    target->size = 0;
    target->max_size = 0;
}

unsigned char
natural_add_u(nat_ptr target, const nat_ptr a, NATURAL_TYPE b)
{
    int i;
    unsigned char overflow;
    unsigned int size;
    NATURAL_TYPE *value;
    NATURAL_TYPE *aux;

    size = a->max_size;
    value = MALLOC_TYPE(size, NATURAL_TYPE);
    if (value == NULL) {
        return 1;
    }
    for (i = 0; i < size; i++) {
        value[i] = a->value[i] + b;
        if ((NATURAL_MAX - a->value[i]) < b) {
            b = 1;
        }
        else {
            b = 0;
            break;
        }
    }
    if (b == 1) {
        aux = REALLOC_TYPE(value, size + 1, NATURAL_TYPE);
        if (aux == NULL) {
            free(value);
            return 2;
        }
        value = aux;
        value[size] = 1;
        size++;
    }
    free(target->value);
    target->value = value;
    target->size = size;
    target->max_size = size;

    return 0;
}

unsigned char
natural_add(nat_ptr target, const nat_ptr a, const nat_ptr b)
{
    int i;
    unsigned int carry;
    unsigned int size;
    NATURAL_TYPE *value;
    NATURAL_TYPE *aux;
    nat_ptr big, small;

    if (a->max_size < b->max_size) {
        big = b;
        small = a;
    }
    else {
        big = a;
        small = b;
    }

    size = big->max_size;
    value = MALLOC_TYPE(size, NATURAL_TYPE);
    if (value == NULL) {
        return 1;
    }
    carry = 0;
    for (i = 0; i < small->max_size; i++) {
        value[i] = a->value[i] + b->value[i];
        if ((NATURAL_MAX - a->value[i]) >= b->value[i]) {
            if (carry == 1 && NATURAL_MAX > value[i]) {
                value[i] += 1;
                carry = 0;
            }
            else if (carry == 1) {
                value[i] = 0;
                carry = 1;
            }
        }
        else {
            value[i] += carry;
            carry = 1;
        }
    }
    for (i = small->max_size; i < big->max_size; i++) {
        if (carry == 1 && big->value[i] == NATURAL_MAX) {
            value[i] = 0;
            carry = 1;
        }
        else {
            value[i] = big->value[i] + carry;
            carry = 0;
        }
    }
    if (carry == 1) {
        aux = REALLOC_TYPE(value, size + 1, NATURAL_TYPE);
        if (aux == NULL) {
            free(value);
            return 2;
        }
        value = aux;
        value[size] = 1;
        size++;
    }
    free(target->value);
    target->value = value;
    target->size = size;
    target->max_size = size;

    return 0;
}

unsigned char
natural_incr(nat_ptr target)
{
    return natural_add_ull(target, target, 1);
}


unsigned char
natural_div_u(nat_ptr target, NATURAL_TYPE *remainder, const nat_ptr a, NATURAL_TYPE b)
{
    int cmp;
    unsigned int i, bit_count, max_bits;
    unsigned char res;
    NATURAL_TYPE aux;

    cmp = natural_cmp_u(a, b);
    if (cmp < 0) {
        *remainder = natural_get_u(a);
        return natural_zero(target);
    }
    else if (cmp == 0) {
        res = natural_zero(target);
        if (res != 0) {
            return res;
        }
        *remainder = 0;
        return natural_incr(target);
    }

    *remainder = 0;
    max_bits = 8 * sizeof(NATURAL_TYPE);
    for (i = a->max_size - 1; i >= 0; i--) {
        bit_count = count_bits(*remainder);
        if (bit_count != 0) {
            aux = (a->value[i] >> bit_count) | (remainder << (max_bits - bit_count));
            *remainder = aux / b;
        }
    }
}


int
natural_cmp_u(const nat_ptr a, NATURAL_TYPE b)
{
    unsigned int i;
    int result = 0;

    if (a->max_size > 1) {
        result = 1;
    }
    else {
        if (a->value[0] < b) {
            result = -1;
        }
        else if (a->value[0] > b) {
            result = 1;
        }
    }

    return result;
}


int
natural_cmp(const nat_ptr a, const nat_ptr b)
{
    unsigned int i;
    int result = 0;

    if (a->max_size < b->max_size) {
        result = -1;
    }
    else if (a->max_size > b->max_size) {
        result = 1;
    }
    else {
        for (i = a->max_size - 1; i >= 0; i--) {
            if (a->value[i] < b->value[i]) {
                result = -1;
                break;
            }
            else if (a->value[i] > b->value[i]) {
                result = 1;
                break;
            }
        }
    }

    return result;
}


unsigned char
natural_setbit(nat_ptr target, unsigned long bit, unsigned char value)
{
    unsigned int i, bits_per_slice, slice, mod_bit;
    NATURAL_TYPE *aux;

    if (value > 1) {
        return 1;
    }
    bits_per_slice = 8 * sizeof(NATURAL_TYPE);
    slice = bit / bits_per_slice;
    if (slice >= target->size) {
        if (value == 0) {
            return 0;
        }
        aux = REALLOC_TYPE(target->value, slice + 1, NATURAL_TYPE);
        if (aux == NULL) {
            return 2;
        }
        target->value = aux;
        for (i = slice; i >= target->size; i--) {
            target->value[i] = 0;
        }
    }
    mod_bit = value << (bit % bits_per_slice);
    target->value[slice] = target->value[slice] | mod_bit;
    if (target->max_size > 1 && target->max_size == slice - 1) {
        for (i = target->max_size - 1; i > 0; i--) {
            if (target->value[i] == 0) {
                target->max_size--;
            }
            else {
                break;
            }
        }
    }

    return result;
}


unsigned char
natural_testbit(const nat_ptr target, unsigned long bit)
{
    unsigned int i, bits_per_slice, slice, mod_bit;
    NATURAL_TYPE value;
    unsigned char result = 0;

    bits_per_slice = 8 * sizeof(NATURAL_TYPE);
    slice = bit / bits_per_slice;
    if (slice >= target->size) {
        return 0;
    }
    mod_bit = value << (bit % bits_per_slice);
    value = target->value[slice] & mod_bit;
    if (value != 0) {
        result = 1;
    }

    return result;
}

char*
natural_to_str(const nat_ptr target) {
    NATURAL_TYPE bit_count;
    unsigned int bits_per_slice;
    unsigned int decimal_digits;

    bits_per_slice = 8 * sizeof(NATURAL_TYPE);
    bit_count = bits_per_slice * target->max_size;
    decimal_digits = (bit_count / 3) + 1;

    return NULL;
}

void
natural_free_str(char* str) {
    free(str);
}

unsigned int
count_bits(NATURAL_TYPE number) {
    int count = 0;
    if (number != 0) {
        count++;
        while (number != 1) {
            number = number >> 1;
            count++;
        }
    }
    return count;
}
