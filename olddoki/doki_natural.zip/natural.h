#ifndef __NATURAL_H
#define __NATURAL_H

#include <limits.h>

#define NATURAL_TYPE unsigned long long int
#define NATURAL_MAX ULLONG_MAX
#define COMPLEX_TYPE double _Complex
#define MALLOC_TYPE(n, type) ((type *) malloc((n) * sizeof(type)))
#define CALLOC_TYPE(n, type) ((type *) calloc((n), sizeof(type)))
#define REALLOC_TYPE(p, n, type) ((type *) realloc((p), (n) * sizeof(type)))

typedef struct
{
  /* number of elements in the value array */
  unsigned int  size;
  /* number of elements in the value array without zeros on the msb */
  unsigned int  max_size;
  /* value from least to most significant bits */
  NATURAL_TYPE *value;
} __nat_struct;

typedef __nat_struct *nat_ptr;

/**
 * natural_dup: copies source natural number into target
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 */
unsigned char
natural_dup(nat_ptr target, const nat_ptr source);

/**
 * natural_zero: initializes given natural number to zero
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 */
unsigned char
natural_zero(nat_ptr target);

/**
 * natural_clear: frees memory used by this natural number
 */
void
natural_clear(nat_ptr target);

/**
 * natural_get_u: return target as an unsigned type
 *     if target is too bit only the least
 *     significant bits will be returned
 */
NATURAL_TYPE
natural_get_u(const nat_ptr target);

/**
 * natural_add_u: target = a + b
 * target must have been previously initialized
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 *     2 -> Failed to reallocate memory in case of overflow
 */
unsigned char
natural_add_u(nat_ptr target, const nat_ptr a, NATURAL_TYPE b);

/**
 * natural_add: target = a + b
 * target must have been previously initialized
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 *     2 -> Failed to reallocate memory in case of overflow
 */
unsigned char
natural_add(nat_ptr target, const nat_ptr a, const nat_ptr b);

/**
 * natural_incr: target++
 * target must have been previously initialized
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 *     2 -> Failed to reallocate memory in case of overflow
 */
unsigned char
natural_incr(nat_ptr target);

/**
 * natural_div_u: a = b * target + remainder
 * target must have been previously initialized
 * return:
 *     0 -> OK
 *     1 -> Failed to allocate memory
 */
 unsigned char
 natural_div_u(nat_ptr target, NATURAL_TYPE *remainder, const nat_ptr a, NATURAL_TYPE b)

/**
 * natural_cmp: compares a and b
 * return:
 *     value = 0 -> a == b
 *     value < 0 -> a < b
 *     value > 0 -> a > b
 */
int
natural_cmp(const nat_ptr a, const nat_ptr b);

/**
 * natural_cmp_u: compares a and b
 * return:
 *     value = 0 -> a == b
 *     value < 0 -> a < b
 *     value > 0 -> a > b
 */
int
natural_cmp_u(const nat_ptr a, NATURAL_TYPE b)

/**
 * natural_cmp: compares a and b
 * target must have been previously initialized
 * return:
 *     value = 0 -> a == b
 *     value < 0 -> a < b
 *     value > 0 -> a > b
 */
int
natural_cmp_u(const nat_ptr a, NATURAL_TYPE b);

/**
 * natural_setbit: sets specified bit to specified value
 * target must have been previously initialized
 * return:
 *     0 -> OK
 *     1 -> value is not boolean
 *     2 -> Failed to reallocate memory in case of overflow
 */
unsigned char
natural_setbit(nat_ptr target, unsigned long bit, unsigned char value);

/**
 * natural_setbit: gets specified bit from target
 * target must have been previously initialized
 * return: 0 or 1
 */
unsigned char
natural_testbit(const nat_ptr target, unsigned long bit)

/**
 * natural_setbit: gets specified bit from target
 * target must have been previously initialized
 * return: 0 or 1
 */
unsigned char
natural_to_str(char *str, const nat_ptr target)

/**
 * count_bits: returns the position of the most significant bit set to one
 * return:
 *     0 -> if number = 0
 *     position of most significant one
 */
unsigned int
count_bits(NATURAL_TYPE number);

#endif
